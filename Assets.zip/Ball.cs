using System.Numerics;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float speed;
    public Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Launch();
    }

    // Update is called once per frame
    public void Reset()
    {
        rb.linearVelocity = UnityEngine.Vector2.zero;
        transform.position = new UnityEngine.Vector2(0, 0);
        Launch();
    }

    private void Launch()
    {
        int x;
        if (Random.Range(0, 2) == 1)
            x = -1;
        else
            x = 1;

        int y;
        if (Random.Range(0, 2) == 1)
            y = -1;
        else
            y = 1;

        rb.linearVelocity = new UnityEngine.Vector2(speed * x, speed * y);
    }
}
