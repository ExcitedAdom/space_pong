using UnityEngine.SceneManagement;
using UnityEngine;

public class ResetGame : MonoBehaviour
{
    public void ResetButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}