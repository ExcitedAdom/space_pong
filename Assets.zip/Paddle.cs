using System.Numerics;
using UnityEngine;

public class Paddle : MonoBehaviour
{
    public bool isPlayer1;
    public float speed;
    public Rigidbody2D rb;
    private float _movement;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    // void Start()
    // {

    // }

    // Update is called once per frame
    void Update()
    {
        if (isPlayer1)
        {
            _movement = Input.GetAxisRaw("Vertical1");
        }
        else
        {
            _movement = Input.GetAxisRaw("Vertical2");
        }
        rb.linearVelocity = new UnityEngine.Vector2(0, _movement * speed);
    }

    public void Reset()
    {
        rb.linearVelocity = UnityEngine.Vector2.zero;
        transform.position = new UnityEngine.Vector2(transform.position.x, 0);
    }
}
