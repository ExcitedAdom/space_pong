using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("Ball")]
    public GameObject Ball;

    [Header("Player1")]
    public GameObject Player1;
    public GameObject Player1Goal;

    [Header("Player2")]
    public GameObject Player2;
    public GameObject Player2Goal;

    [Header("Scores")]
    public TMP_Text Player1Score;
    public TMP_Text Player2Score;

    private int _Player1Score = 0;
    private int _Player2Score = 0;

    public void Player1Scored()
    {
        _Player1Score = _Player1Score + 1;
        Player1Score.GetComponent<TextMeshProUGUI>().text = _Player1Score.ToString();
        ResetPosition();
    }

    public void Player2Scored()
    {
        _Player2Score = _Player2Score + 1;
        Player2Score.GetComponent<TextMeshProUGUI>().text = _Player2Score.ToString();
        ResetPosition();
    }

    private void ResetPosition()
    {
        Ball.GetComponent<Ball>().Reset();
        Player1.GetComponent<Paddle>().Reset();
    }
}